import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BookComponent} from "./book/book.component";
import {GiftComponent} from "./gift/gift.component";
import {ClothingComponent} from "./clothing/clothing.component";
import {SportComponent} from "./sport/sport.component";
import {HomeComponent} from "./home/home.component";
import {LoginComponent} from "./login/login.component";
import {LoginGuard} from "./utility/loginguard";
import {MenuComponent} from "./menu/menu.component";
import {SidemenuComponent} from "./sidemenu/sidemenu.component";
import {UserhomeComponent} from "./userhome/userhome.component";


const routes: Routes = [
  {
    path:'Login',
    component:LoginComponent
  },
  {
     path:'UserHome',
     component:UserhomeComponent
  },

  {
     path:'TopMenu',
     component:MenuComponent,
    canActivate:[LoginGuard],
    canActivateChild:[LoginGuard],
    children:[
      {
        path:'Home',
        component:HomeComponent
      },
      {
        path: 'Accounts',
        loadChildren:() => import('./accounts/accounts.module')
          .then(m => m.AccountsModule)
      }
    ]

    },
  {
    path:'SideMenu',
    component:SidemenuComponent,
    canActivate:[LoginGuard],
    canActivateChild:[LoginGuard],
    children: [
      {
        path:'Books',
        component:BookComponent
      },
      {
        path:'Gifts',
        component:GiftComponent
      },
      {
        path:'Clothing',
        component:ClothingComponent
      },
      {
        path:'Sports',
        component:SportComponent
      },
    ]
  },

  { path: '', redirectTo: '/Login', pathMatch: 'full' },
  { path: '**', redirectTo: '/Login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
