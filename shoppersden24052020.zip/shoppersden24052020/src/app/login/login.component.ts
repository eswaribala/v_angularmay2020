import { Component, OnInit } from '@angular/core';
import {User} from "../menu/user";
import {LoginService} from "../services/login.service";
import {Router} from "@angular/router";
import {AuthService} from "../utility/auth.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //template driven
  //user instance
  user=new User('','');
  errMessage:any='';
  constructor(private loginService:LoginService,private router:Router,private authService:AuthService) { }

  ngOnInit() {
  }

  login(event) {
    event.preventDefault();
    console.log(this.user);
    this.loginService.validateUser(this.user).subscribe(response=>{
      console.log(response);

      if (response == null) {
        this.errMessage = 'UserName/Password invalid';
      } else {
        this.errMessage = '';
        // @ts-ignore
        this.authService.sendToken(response.email);
        //this.router.navigate(['/Menu']);
        this.router.navigate(['/UserHome']);

      }

    });
  }
}
