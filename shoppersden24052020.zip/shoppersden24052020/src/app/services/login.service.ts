import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) {

  }

  public validateUser(userObj:any):Observable<any>
  {
//pivotal cf
    //http://localhost:7070/addboauser
    //api gateway
    return this.http.get('https://blog-cf.cfapps.io/findboauserbyname/'+userObj.userName);


  }

}
