import { Injectable } from '@angular/core';
import {MenuData} from '../models/menudata';
import {SideMenuData} from "../models/sidemenudata";

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor() { }

  getMenuData()
  {
    return MenuData;
  }

  getSideMenuData()
  {
    return SideMenuData;
  }


}
