import {FirstSubMenu, Menu, SecondSubMenu} from './menu';

export const MenuData:Menu[]=[new Menu('Home','pi pi-fw pi-home',
  [new FirstSubMenu('DashBoard','',
    [new SecondSubMenu('Customer','',''),
      new SecondSubMenu('Market','','')
    ],
    ''),
    new FirstSubMenu('Management','',
      [new SecondSubMenu('Director','',''),
        new SecondSubMenu('President','','')
      ],
      ''),
    new FirstSubMenu('Products','',
      [new SecondSubMenu('Banking','',''),
        new SecondSubMenu('Investment','','')
      ],
      '')


  ],
  ''),
  new Menu('Admin','pi pi-fw pi-user',
    [new FirstSubMenu('Inbox','',
      [new SecondSubMenu('','','')],
      '')],
    ''),
  new Menu('My Accounts','pi pi-fw pi-plus',
    [new FirstSubMenu('Profile','',
      [new SecondSubMenu('','','')],
      '')],
    ''),
  new Menu('FAQ','pi pi-fw pi-plus',
    [new FirstSubMenu('Forum','',
      [new SecondSubMenu('','','')],
      '')],
    ''),
  new Menu('About us','pi pi-fw pi-plus',
    [new FirstSubMenu('Contact','',
      [new SecondSubMenu('','','')],
      '')],
    ''),
  new Menu('Help','pi pi-fw pi-plus',
    [new FirstSubMenu('','',
      [new SecondSubMenu('','','')],
      '')],
    '')

]
