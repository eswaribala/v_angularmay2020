import { Component, OnInit } from '@angular/core';
import {CountryService} from "../services/country.service";
import {MenuService} from "../services/menu.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.css']
})
export class SidemenuComponent implements OnInit {

  searchItem:any;
  countries:any;
  selectedCountry:any;
  sideMenuData:any;
  active = 'top';
  //dependency injection
  constructor(private countryService:CountryService,
              private menuService:MenuService,private router:Router) {

  }

  ngOnInit() {
    this.countryService.getCountries().subscribe(response=>{
      console.log(response);
      this.countries=response;
    })
   // this.sideMenuData=["Books","Gifts","Clothing","Sports"];
   this.sideMenuData=this.menuService.getSideMenuData();

  }

  doSearch() {
      console.log(this.searchItem);
  }

  getSelectedCountry(event) {
     console.log(this.selectedCountry);
  }

  getComponent(event) {
        console.log(event);
        this.router.navigate(['/SideMenu/'+event]);
  }
}
