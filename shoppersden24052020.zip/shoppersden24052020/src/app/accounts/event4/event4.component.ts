import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event4',
  templateUrl: './event4.component.html',
  styleUrls: ['./event4.component.css']
})
export class Event4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
