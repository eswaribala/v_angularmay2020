import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {Event1Component} from "./event1/event1.component";
import {Event2Component} from "./event2/event2.component";
import {Event3Component} from "./event3/event3.component";
import {Event4Component} from "./event4/event4.component";


const routes: Routes = [
  {
    path:'Event1',
    component:Event1Component
  },
  {
    path:'Event2',
    component:Event2Component
  },
  {
    path:'Event3',
    component:Event3Component
  },
  {
    path:'Event4',
    component:Event4Component
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountsRoutingModule { }
