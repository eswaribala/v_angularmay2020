import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Event1Component } from './event1/event1.component';
import { Event2Component } from './event2/event2.component';
import { Event3Component } from './event3/event3.component';
import { Event4Component } from './event4/event4.component';
import { AccountComponent } from './account/account.component';
import {AccountsRoutingModule} from "./accounts-routing.module";



@NgModule({
  declarations: [Event1Component, Event2Component, Event3Component,
    Event4Component, AccountComponent],
  imports: [
    CommonModule,
    AccountsRoutingModule
  ]
})
export class AccountsModule { }
