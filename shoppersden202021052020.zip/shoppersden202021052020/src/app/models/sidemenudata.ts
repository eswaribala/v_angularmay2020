import {SideMenu} from "./sidemenu";

export const SideMenuData:SideMenu[]=[

  new SideMenu('Books','pi pi-fw pi-cog',''),
  new SideMenu('Gifts','pi pi-fw pi-cog',''),
  new SideMenu('Clothing','pi pi-fw pi-cog',''),
  new SideMenu('Sports','pi pi-fw pi-cog','')

]
