import {Component, Inject, OnInit} from '@angular/core';
import {MenuService} from '../services/menu.service';
// @ts-ignore
import * as menudata from '../data.json';
// @ts-ignore
//import {MegaMenuItem,MenuItem} from 'primeng/api';
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  data:any;
  //dependency injection
  constructor( private menuService:MenuService) { }

  ngOnInit() {
    console.log(menudata.items);
     //this.data=this.menuService.getMenuData();
     this.data=menudata.items;
  }

}
