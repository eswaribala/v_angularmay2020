import {Component, Inject, OnInit} from '@angular/core';
import {MenuService} from '../services/menu.service';
// @ts-ignore
import * as data from '../data.json';
// @ts-ignore
//import {MegaMenuItem,MenuItem} from 'primeng/api';
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  data:any;
  //dependency injection
  constructor( private menuService:MenuService) { }

  ngOnInit() {
    console.log(data.items);
     //this.data=this.menuService.getMenuData();
     this.data=data.items;
  }

}
