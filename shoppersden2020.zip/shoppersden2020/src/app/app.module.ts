import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';

import {MenubarModule} from 'primeng/menubar';
import {MegaMenuModule} from 'primeng/megamenu';


@NgModule({
  declarations: [
    AppComponent,
    MenuComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
  MenubarModule,
  MegaMenuModule


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
